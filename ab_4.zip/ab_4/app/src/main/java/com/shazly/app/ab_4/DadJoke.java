package com.shazly.app.ab_4;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;

import com.shazly.app.ab_4.databinding.ActivityDadJokeBinding;

public class DadJoke extends BaseActivity {
    private ActivityDadJokeBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityDadJokeBinding.inflate(getLayoutInflater());
        setContentLayout(R.layout.activity_dad_joke);
    }
}